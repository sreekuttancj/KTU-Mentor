package com.ktu_mantra.ktu.ktumantra_syllabusquestionpaperandcgpacalculator

class Sample {
}