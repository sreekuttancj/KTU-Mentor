package com.ktu_mantra.ktu.ktumantra_syllabusquestionpaperandcgpacalculator.color_list;


public abstract interface ColorInterface {

    public abstract void setColorPosition(int position);

}
