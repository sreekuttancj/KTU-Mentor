package com.ktu_mantra.ktu.ktumantra_syllabusquestionpaperandcgpacalculator.lesson;


public abstract interface HtDialogInterface {

    public abstract void setClickAction(HTDialog htDialog, int paramInt);

}
