package com.ktu_mantra.ktu.ktumantra_syllabusquestionpaperandcgpacalculator.lesson;


public abstract interface LessonListInterface {

    public abstract void setLessonListItem(LessonListItem lessonListItem);
}
